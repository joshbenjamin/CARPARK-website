'''
    URLs

    These are the URL extensions to which you are able to navigate to.
    Each URL maps to a different subsegment of a view.

'''

from django.contrib import admin
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from DB import views

urlpatterns = [

    # In order to access the admin page to make edits
    path('admin/', admin.site.urls),

    # To obtain the availability of a single parking lot
    # Also used to update the cars in a parking lot
    path('api/Parkings/', views.ParkingList.as_view()),
    
    # Used to get parking information for all parking lots on a given campus 
    path('api/Parking-Lots/', views.ParkingLotList.as_view()),
    
    # Used to get historical data for parking, from the day before, to see the frequency of parking
    path('api/Parking-Days/', views.ParkingDayList.as_view()),
    
    # Used to view the contents of the database in a table form
    path('DB_view/', views.DB_view),

]
