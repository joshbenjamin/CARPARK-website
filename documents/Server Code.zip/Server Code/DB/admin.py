from django.contrib import admin
from . models import Campus, ParkingLot, Parking

# The models used are registered here so that they become editable in the Django Admin panel

admin.site.register(Campus)
admin.site.register(ParkingLot)
admin.site.register(Parking)