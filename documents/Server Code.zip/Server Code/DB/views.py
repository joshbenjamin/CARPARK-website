'''

	The various 'views' that are presented once each URL is reached.
	Because this is not a website, but rather an API, the user only views raw data as a result of their HTTP Request, no page.
	Each function relates to different purposes which will be identified below.

'''

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.db import connection
from django.core.serializers.json import DjangoJSONEncoder
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime
from . models import Campus, ParkingLot, Parking
import json
import pytz

# Uses a library to view the database in it's entirety at a certain URL extension
def DB_view(request):
    istekler = Parking.objects.all()
    return render(request, 'DB_view.html', locals())

# In order to get all the information for a specific parking lot, this extension would be triggered
class ParkingList(APIView):

	# This specifies that it was specifically an HTTP GET Request
	def get(self, request):
		
		# This is passed in to the HTTP Request as a parameter, with 'code' key and an associated value
		parking = request.GET.get('code')

		# A raw SQL Query which retrieves the details of the parking lot that is passed in as an argument
		query = """SELECT public."DB_ParkingLots".id, public."DB_ParkingLots"."parkingName", public."DB_ParkingLots"."parkingCode", public."DB_ParkingLots".capacity, public."DB_ParkingLots".available, public."DB_ParkingLots".latitude, public."DB_ParkingLots".longitude, public."DB_Campuses"."campusName", public."DB_ParkingLots"."lastUpdated"
			FROM public."DB_ParkingLots" 
			LEFT JOIN public."DB_Campuses" ON public."DB_ParkingLots"."campus_id" = public."DB_Campuses".id 
			WHERE public."DB_ParkingLots"."parkingCode" = %s"""

		# Crates a connection to the SQL server
		cursor = connection.cursor()
		cursor.execute(query, [parking])

		rows = cursor.fetchall()

		result = []

		keys = ('id', 'parkingName', 'parkingCode', 'capacity', 'available', 'latitude', 'longitude', 'campusName', 'lastUpdated')

		# Adds these values to the results to create a dictionary from where the values will be displayed
		for row in rows:
			result.append(dict(zip(keys, row)))

		# Takes the data and puts it into a JSON (JavaScript Object Notation) format
		json_data = json.dumps(result, cls=DjangoJSONEncoder)

		# Returns the data as a response
		return HttpResponse(json_data, content_type="application/json")


	# This is an HTTP POST Request
	def post(self, request):

		# This method additionally takes the parameter of the status of the car (ENTER/EXIT)
		postStatus = request.POST.get('status')
		postParking = request.POST.get('code')

		# A method to get the current time
		time_now = datetime.now()

		# Instantiated value for the count of a parking lot
		counter = 0;

		# SQL Query to retrieve the latest added entry into the table for a specific parking lot
		countQuery = """
			SELECT public."DB_Parkings".count, public."DB_Parkings"."parkingLot_id", public."DB_ParkingLots".capacity
			FROM public."DB_Parkings"
			LEFT JOIN public."DB_ParkingLots" ON public."DB_Parkings"."parkingLot_id" = public."DB_ParkingLots".id
			WHERE public."DB_ParkingLots"."parkingCode" = %s
			ORDER BY public."DB_Parkings"."time" Desc
			LIMIT 1
		"""

		cursor = connection.cursor()
		cursor.execute(countQuery, [postParking])
		row = cursor.fetchone()

		# Getting the values from the data that has just been acquired
		counter = row[0]
		lot_id = row[1]
		capacity = row[2]

		# Changing the count of how many cars are present based on the status of the paramter
		if postStatus == "ENTER":
				counter += 1 
		elif postStatus == "EXIT":
				counter -= 1

		# Using Django Models, creates a parking instance with the given values
		p = Parking(parkingLot=ParkingLot.objects.get(id=lot_id), status=postStatus, count=counter, time=time_now)
		p.save()

		# Another Django method, which takes in an existing parking lot and make changes to it (such as the count and the last updated) 
		obj, created = ParkingLot.objects.update_or_create(
		    parkingCode=postParking,
		    defaults={'available': capacity-counter, 'lastUpdated': time_now},
		)

		obj.save()

		# Returns the HTTP status of 201 to the user, which indicates that the server has successfully made a change
		return HttpResponse(status=201)


# Gets the details of all parking lots on a specific campus
class ParkingLotList(APIView):

	def get(self, request):
		
		campus = request.GET.get('campus')

		query = """SELECT public."DB_ParkingLots".id, public."DB_ParkingLots"."parkingName", public."DB_ParkingLots"."parkingCode", public."DB_ParkingLots".capacity, public."DB_ParkingLots".available, public."DB_ParkingLots".latitude, public."DB_ParkingLots".longitude, public."DB_Campuses"."campusName", public."DB_ParkingLots"."lastUpdated"
			FROM public."DB_ParkingLots" 
			LEFT JOIN public."DB_Campuses" ON public."DB_ParkingLots"."campus_id" = public."DB_Campuses".id 
			WHERE public."DB_Campuses"."campusName" = %s"""

		cursor = connection.cursor()
		cursor.execute(query, [campus])

		rows = cursor.fetchall()
		result = []

		keys = ('id', 'parkingName', 'parkingCode', 'capacity', 'available', 'latitude', 'longitude', 'campusName', 'lastUpdated')

		for row in rows:
			result.append(dict(zip(keys, row)))

		json_data = json.dumps(result, cls=DjangoJSONEncoder)

		return HttpResponse(json_data, content_type="application/json")


# Used in order to view historical data on when people entered and exited parking lots
class ParkingDayList(APIView):

	def get(self, request):
		
		# Takes in a value for the day that the request is made
		day = request.GET.get('day')
		code = request.GET.get('code')

		# We want to fetch data for the day before
		number_to_subtract = 1

		# If the day is Monday or Sunday, we fetch data from the previous Friday
		if day == 'Monday':
			number_to_subtract = 3
		elif day == 'Sunday':
			number_to_subtract = 2

		# SQL Query which retrieves all parkings within a specified time which is the day before the 
		query = """
			SELECT public."DB_Parkings"."id", public."DB_Parkings".count, public."DB_Parkings".status, public."DB_Parkings"."time", public."DB_ParkingLots"."parkingName", public."DB_ParkingLots".capacity, public."DB_ParkingLots".available
			FROM public."DB_Parkings"
			LEFT JOIN public."DB_ParkingLots" on public."DB_Parkings"."parkingLot_id" = public."DB_ParkingLots".id
			WHERE public."DB_ParkingLots"."parkingCode" = %s
			AND public."DB_Parkings"."time"::date = current_date - %s
		"""

		cursor = connection.cursor()
		cursor.execute(query, [code, number_to_subtract])

		rows = cursor.fetchall()
		result = []

		keys = ('id', 'count', 'status', 'time', 'parkingName', 'capacity', 'available')

		for row in rows:
			result.append(dict(zip(keys, row)))

		json_data = json.dumps(result, cls=DjangoJSONEncoder)

		return HttpResponse(json_data, content_type="application/json")