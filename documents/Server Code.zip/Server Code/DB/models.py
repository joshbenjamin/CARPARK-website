'''

	MODELS
	In this class, the models that are needed are instantiated and created
	The models used are:
		1. Campus - represents each campus that this would be implemented on
		2. Parking Lot - these are each parking lot on campuses, and thus are associated to the campuses
		3. Parking - this details when someone parks in a parking lot

'''

from django.db import models
from datetime import datetime
from django.utils import timezone

class Campus(models.Model):
	
	# These variables are of certain predefined types and are used to define each campus, with it's location
	campusName=models.CharField(max_length=20)
	latitude=models.DecimalField(max_digits=9, decimal_places=6)
	longitude=models.DecimalField(max_digits=9, decimal_places=6)

	# Defines what the name of the Database table will be
	class Meta:
		db_table = 'DB_Campuses'

	# Represents how the model is viewed in the admin panel
	def __str__(self):
		return self.campusName


class ParkingLot(models.Model):

	# Represents the name and identification of the parking lot 
	parkingCode=models.CharField(max_length=3)
	parkingName=models.CharField(max_length=15)

	# This is then linked as a foreign key to the primary key (the id) from the Campus table
	campus=models.ForeignKey(
		Campus, on_delete=models.CASCADE)

	capacity=models.IntegerField(null=False)

	latitude=models.DecimalField(max_digits=9, decimal_places=6)
	longitude=models.DecimalField(max_digits=9, decimal_places=6)

	# Each parking lot has a specific colour (who is allowed to park there) and this is represented by this Enum
	PARKING_TYPE = (
	   ('Y', 'Yellow'),
	   ('R', 'Red'),
	   ('B', 'Black'),
	   ('Bl', 'Blue'),
	   ('G', 'Green'),
	   ('R', 'Rhodes'),
	   ('P', 'PostGrad'),
	   ('V', 'Visitors'),
	)
	colour=models.CharField(max_length=2, choices=PARKING_TYPE, blank=True, help_text="Parking Colour")

	# In conjunction with capacity, this tells how many spots are avaialble
	available=models.IntegerField(null=False, default=0)

	lastUpdated=models.DateTimeField()

	class Meta:
		db_table = 'DB_ParkingLots'

	def __str__(self):
		return self.parkingCode


class Parking(models.Model):

	# The parking lot that this parking entry considered
	parkingLot=models.ForeignKey(
		ParkingLot, on_delete=models.CASCADE)
	
	# The current count of cars in the specific parking lot
	count=models.IntegerField(null=False)

	# Similarly to the parking lot colour, each parking entry has a state of either ENTRY or EXIT
	PARKING_STATES = (
		('ENTER', 'ENTER'),
		('EXIT', 'EXIT'),
	)
	status=models.CharField(max_length=5,
		choices=PARKING_STATES, blank=False,
		help_text='Enter or Exit') 

	time=models.DateTimeField()

	class Meta:
		db_table = 'DB_Parkings'

	def __str__(self):
		return "Current Count: " + str(self.count) + "\n" + "Last Status: " + self.status