from rest_framework import serializers
from . models import Campus, ParkingLot, Parking

'''
	UNUSED
	For the representation of a model
'''

class ParkingSerializer(serializers.ModelSerializer):

	class Meta:
		model=Parking
		fields = '__all__'